Картинки для сайта (формат WEBP, 1600x900)

Положи ВСЕ файлы в репозитории сюда:
  assets/img/

Файлы:
- assets/img/sauna-exterior-a.webp
- assets/img/sauna-steam-a.webp
- assets/img/sauna-lounge-a.webp
- assets/img/sauna-extra-v.webp
- assets/img/apt-living-c.webp
- assets/img/apt-bedroom-a.webp
- assets/img/apt-kitchen-a.webp
- assets/img/apt-extra-v.webp
- assets/img/apt-extra-c.webp
- assets/img/cottage-exterior-a.webp
- assets/img/cottage-exterior-c.webp
- assets/img/cottage-living-a.webp
- assets/img/cottage-living-b.webp
- assets/img/cottage-living-c.webp
- assets/img/cottage-terrace-a.webp
- assets/img/cottage-terrace-b.webp
- assets/img/cottage-extra-a.webp
- assets/img/cottage-extra-c.webp
- assets/img/bg-river-house.webp

Готовые пути для вставки в код:
  "assets/img/sauna-exterior-a.webp"
  "assets/img/sauna-steam-a.webp"
  "assets/img/sauna-lounge-a.webp"
  "assets/img/sauna-extra-v.webp"
  "assets/img/apt-living-c.webp"
  "assets/img/apt-bedroom-a.webp"
  "assets/img/apt-kitchen-a.webp"
  "assets/img/apt-extra-v.webp"
  "assets/img/apt-extra-c.webp"
  "assets/img/cottage-exterior-a.webp"
  "assets/img/cottage-exterior-c.webp"
  "assets/img/cottage-living-a.webp"
  "assets/img/cottage-living-b.webp"
  "assets/img/cottage-living-c.webp"
  "assets/img/cottage-terrace-a.webp"
  "assets/img/cottage-terrace-b.webp"
  "assets/img/cottage-extra-a.webp"
  "assets/img/cottage-extra-c.webp"
  "assets/img/bg-river-house.webp"

Фон в твоём коде уже ищется как:
  const BG_FILE = 'assets/img/bg-river-house.webp'
